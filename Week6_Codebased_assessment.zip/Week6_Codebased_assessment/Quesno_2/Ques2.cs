﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quesno_2
{
    internal class Ques2
    {
        public static void Main(string[] args)
        {
            int[] n = {1,2,3,4,5};
            Console.WriteLine("Sum of all elements=" + n.Sum());
            Console.WriteLine("Average of all elements=" + n.Average());
            Console.WriteLine("Maximum=" + n.Max());
            Console.WriteLine("Minimum=" + n.Min());

        }
    }
}
