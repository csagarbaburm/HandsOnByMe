﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quesno_5
{
    internal class Ques5
    {
        static void Main()
        {
            List<Student> students = new List<Student>()
            {
                new Student{Id=1,Name="Nidhin"},
                  new Student{Id=2,Name="Nevin"},
                    new Student{Id=3,Name="Nanma"}
            };

            List<Enroll> enrolls = new List<Enroll>()
            {
                new Enroll{studid=1,Course="Physics"},
                  new Enroll{studid=2,Course="Chemistry"},
                    new Enroll{studid=3,Course="Zoology"}
            };
            var query = from student in students
                        join enroll in enrolls on student.Id equals enroll.studid
                        select new { student.Name, enroll.Course };

            foreach (var item in query)
            {
                Console.WriteLine($"Student: {item.Name}, Course: {item.Course}");
            }
        }
    }

    class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
    class Enroll
    {
        public int studid { get; set; }
        public string Course { get; set; }
    }
}

