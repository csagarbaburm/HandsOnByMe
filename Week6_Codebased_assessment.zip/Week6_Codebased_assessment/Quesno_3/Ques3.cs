﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quesno_3
{
    internal class Ques3
    {
        static bool isPrime(int num)
        {
            if (num == 1 || num == 0) return false;
            for (int i = 2; i < num; i++)
            {
                if (num % i == 0) return false;
            }
            return true;
        }
        public static void Main(String[] args)
        {
            Console.WriteLine("Enter a limit:");
            int num = int.Parse(Console.ReadLine());
            for (int i = 1; i <= num; i++)
            {
                if (isPrime(i))
                {
                    Console.Write(i + " ");
                }
            }

        }
    }
}
