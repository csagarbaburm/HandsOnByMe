﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quesno_1
{
    internal class Ques1
    {
        static void Main(string[] args)
        {
         
                do
                {
                    Console.WriteLine("Enter a number between 0 to 5");
                    int n = int.Parse(Console.ReadLine());
                    int rndno = new Random().Next(0, 5);
                    if (rndno == n)
                    {
                        Console.WriteLine("The entered no " + n + " is matching");

                    }
                    else
                    {
                        Console.WriteLine("The entered no " + n + " is not matching");
                    }
                break;
                }
                while (true);
            
        }
    }
}
