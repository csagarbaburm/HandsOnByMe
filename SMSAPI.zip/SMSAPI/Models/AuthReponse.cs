﻿namespace SMSAPI.Models
{
    public class AuthReponse
    {
        public string UserId { get; set; }
        public string Role { get; set; }
        public string Token { get; set; }
    }
}
