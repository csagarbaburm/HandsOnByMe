import React from "react";

export default function NoPage() {
  return <div>No Page Found!!</div>;
}
