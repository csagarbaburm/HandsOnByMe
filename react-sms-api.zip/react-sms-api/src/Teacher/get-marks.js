import React from "react";

export default function GetMarks() {
  return <div>show-marks</div>;
}
