import React from "react";

export default function Contact() {
  return <div>This is Contact Page!!</div>;
}
