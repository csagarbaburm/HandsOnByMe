import React from "react";

export default function Courses() {
  return <div>This is Course Page!!</div>;
}
