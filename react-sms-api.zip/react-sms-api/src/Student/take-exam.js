import React from "react";

export default function TakeExam() {
  return <div>take-exam</div>;
}
