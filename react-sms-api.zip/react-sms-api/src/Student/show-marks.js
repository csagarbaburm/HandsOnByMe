import React from "react";

export default function ShowMarks() {
  return <div>show-marks</div>;
}
