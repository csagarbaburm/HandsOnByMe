﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Week4Challenge.Entities;
using Week4Challenge.Repositories;

namespace Week4Challenge.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CompanyController : ControllerBase
    {

        CompanyRepository CompanyRepository;

        public CompanyController(CompanyRepository companyRepository)
        {
            CompanyRepository = companyRepository;
        }

        [HttpPost("AddCompany")]
        public IActionResult AddCompany(Company company)
        {
            try
            {
                CompanyRepository.AddCompany(company);
                return Ok();
            }
            catch (Exception e)
            {

                return BadRequest(e.Message);
            }
        }

        [HttpGet("GetAllCompanies")]
        public IActionResult GetAllCompanies()
        {
            try
            {
                return Ok(CompanyRepository.GetAllCompanies());
            }
            catch (Exception e)
            {

                return BadRequest(e.Message);
            }
        }

        [HttpGet("GetCompanyByName/{name}")]
        public IActionResult GetCompany(string name) 
        {
            try
            {
                return Ok(CompanyRepository.GetCompanyByName(name));
            }
            catch (Exception e)
            {

                return BadRequest(e.Message);
            }
        }

        [HttpGet("GetAllCompaniesByCity/{city}")]
        public IActionResult GetCompaniesByCity(string city) 
        {
            try
            {
                return StatusCode(200, CompanyRepository.GetCompaniesByCity(city));
            }
            catch (Exception e)
            {

                return BadRequest(e.Message);
            }
        }

        [HttpPut("UpdateCompany")]
        public IActionResult PutCompany(Company company)
        {
            try
            {
                CompanyRepository.UpdateCompany(company);
                return Ok();
            }
            catch (Exception e)
            {

                return BadRequest(e.Message);
            }
        }

        [HttpDelete("DeleteCompany/{id}")]
        public IActionResult DeleteCompany(int id) 
        {
            try
            {
                CompanyRepository.DeleteCompany(id);
                return Ok();
            }
            catch (Exception e)
            {

                return BadRequest(e.Message);
            }
        }

    }
}
