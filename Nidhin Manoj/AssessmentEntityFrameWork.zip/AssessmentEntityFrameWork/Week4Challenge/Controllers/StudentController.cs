﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Update.Internal;
using Week4Challenge.Entities;
using Week4Challenge.Repositories;

namespace Week4Challenge.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        StudentRepository studentRepository;

        public StudentController(StudentRepository studentRepository)
        {
            this.studentRepository = studentRepository;
        }


        [HttpPost("AddStudent")]
        public IActionResult AddStudent(Student student) 
        {
            try
            {
                studentRepository.AddStudent(student);
                return Ok(student);
            }
            catch (Exception e)
            {

                return BadRequest(e.Message);
            }
        }

        [HttpGet("GetStudentByID/{id}")]
        public IActionResult GetStudent(int id) 
        {
            try
            {
                return StatusCode(200, studentRepository.GetStudentById(id));
            }
            catch (Exception e)
            {

                return BadRequest(e.Message);
            }

        }
        [HttpGet("GetStudentByName/{name}")]
        public IActionResult GetStudentByName(string name) 
        {
            try
            {
                return StatusCode(200, studentRepository.GetStudentName(name));
            }
            catch (Exception e)
            {

                return BadRequest(e.Message);
            }
        }

        [HttpGet("GetStudentsByQualification/{qualification}")]
        public IActionResult GetStudentsByQualification(string qualification)
        {
            try
            {
                return StatusCode(200, studentRepository.GetAllStudentByQualification(qualification));
            }
            catch (Exception e)
            {

                return BadRequest(e.Message);
            }
        }

        [HttpGet("GetStudentsBySkill/{skill}")]
        public IActionResult GetStudentsBySkill(string skill)
        {
            try
            {
                return StatusCode(200, studentRepository.GetAllStudentBySkills(skill));
            }
            catch (Exception e)
            {

                return BadRequest(e.Message);
            }
        }

        [HttpPut("UpdateStudentDetails")]
        public IActionResult UpdateStudent(Student student) 
        {
            try
            {
                studentRepository.UpdateStudent(student);
                return Ok(student);
            }
            catch (Exception e)
            {

                return BadRequest(e.Message);
            }
        }

        [HttpDelete("DeleteStudent/{id}")]
        public IActionResult DeleteStudent(int id)
        {
            try
            {
                studentRepository.DeleteStudent(id);
                return Ok();
            }
            catch (Exception e)
            {

                return BadRequest(e.Message);
            }
        }

    }
}
