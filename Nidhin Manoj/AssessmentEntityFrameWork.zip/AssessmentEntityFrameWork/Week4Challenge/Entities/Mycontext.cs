﻿using Microsoft.EntityFrameworkCore;

namespace Week4Challenge.Entities
{
    public class Mycontext:DbContext
    {
        IConfiguration configuration;

        public Mycontext(IConfiguration configuration)
        {
            this.configuration = configuration;
        }

        public DbSet<Company> companies { get; set; }
        public DbSet<Student> students { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(configuration.GetConnectionString("MyConnection"));
        }

    }
}
