﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Week4Challenge.Entities
{
    public class Student
    {
        [Key]
        [Column("StudentID", TypeName = "int")]
        public int Id { get; set; }
        [Required]
        [Column("StudentName", TypeName = "varchar")]
        [StringLength(40)]
        public string Name { get; set; }
        [Required]
        [Column("Qualification", TypeName = "varchar")]
        [StringLength(30)]
        public string Qualification { get; set; }
        [Required]
        [Column("Skill", TypeName = "varchar")]
        [StringLength(30)]
        public string Skill { get; set; }
    }
}
