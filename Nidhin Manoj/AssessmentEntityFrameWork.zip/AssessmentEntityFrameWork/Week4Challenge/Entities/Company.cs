﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Week4Challenge.Entities
{
    public class Company
    {
        [Key]
        [Column("CompanyID", TypeName ="int")]
        public int Id { get; set; }
        [Required]
        [Column("CompanyName", TypeName = "varchar")]
        [StringLength(40)]
        public string Name { get; set; }
        [Required]
        [Column("City", TypeName = "varchar")]
        [StringLength(20)]
        public string City { get; set; }
        [Required]
        [Column("Address", TypeName = "varchar")]
        [StringLength(50)]
        public string Address { get; set; }

    }
}
