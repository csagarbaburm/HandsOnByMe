﻿using Week4Challenge.Entities;

namespace Week4Challenge.Repositories
{
    public class StudentRepository : IStudentRepository
    {
        Mycontext mycontext;

        public StudentRepository(Mycontext mycontext)
        {
            this.mycontext = mycontext;
        }

        public void AddStudent(Student student)
        {
            mycontext.students.Add(student);
            mycontext.SaveChanges();
        }

        public void DeleteStudent(int id)
        {
            Student student = mycontext.students.Find(id);
            mycontext.students.Remove(student);
            mycontext.SaveChanges();
        }

        public List<Student> GetAllStudentByQualification(string qualification)
        {
            List<Student> students = (from s in mycontext.students
                                      where s.Qualification==qualification
                                      select s).ToList();
            return students;
        }

        public List<Student> GetAllStudentBySkills(string skill)
        {
            List<Student> students = (from s in mycontext.students
                                      where s.Skill == skill
                                      select s).ToList();
            return students;
        }

        public Student GetStudentById(int id)
        {
            return mycontext.students.Find(id);
        }

        public Student GetStudentName(string name)
        {
            return mycontext.students.SingleOrDefault(s => s.Name == name);
        }

        public void UpdateStudent(Student student)
        {
            mycontext.students.Update(student);
            mycontext.SaveChanges();
        }
    }
}
