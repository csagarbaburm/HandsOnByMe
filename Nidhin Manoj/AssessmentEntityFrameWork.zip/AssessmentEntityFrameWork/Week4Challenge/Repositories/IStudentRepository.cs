﻿using Week4Challenge.Entities;

namespace Week4Challenge.Repositories
{
    public interface IStudentRepository
    {
        void AddStudent(Student student);
        List<Student> GetAllStudentByQualification(string qualification);
        List<Student> GetAllStudentBySkills(string skill);
        Student GetStudentById(int id);
        Student GetStudentName(string name);
        void UpdateStudent(Student student);
        void DeleteStudent(int id);
    }
}
