﻿using Week4Challenge.Entities;

namespace Week4Challenge.Repositories
{
    public interface ICompanyRepository
    {
        void AddCompany(Company company);
        Company GetCompanyByName(string name);
        List<Company> GetAllCompanies();
        List<Company> GetCompaniesByCity(string city);
        void UpdateCompany(Company company);
        void DeleteCompany(int id);

    }
}
