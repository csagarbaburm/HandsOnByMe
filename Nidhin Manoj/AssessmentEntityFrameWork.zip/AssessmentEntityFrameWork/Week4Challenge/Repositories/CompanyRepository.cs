﻿using Week4Challenge.Entities;

namespace Week4Challenge.Repositories
{
    public class CompanyRepository : ICompanyRepository
    {
        Mycontext mycontext;

        public CompanyRepository(Mycontext mycontext)
        {
            this.mycontext = mycontext;
        }

        public void AddCompany(Company company)
        {
            mycontext.companies.Add(company);
            mycontext.SaveChanges();
        }

        public void DeleteCompany( int id)
        {
            Company company = mycontext.companies.Find(id);
            mycontext.Remove(company);
            mycontext.SaveChanges();
        }

        public List<Company> GetAllCompanies()
        {
            return mycontext.companies.ToList();
        }

        public List<Company> GetCompaniesByCity(string city)
        {
            List<Company> SelectedCompanies = (from c in mycontext.companies
                                               where c.City==city
                                               select c).ToList();
            return SelectedCompanies;
        }

        public Company GetCompanyByName(string name)
        {
            return mycontext.companies.SingleOrDefault(s => s.Name == name);
        }

        public void UpdateCompany(Company company)
        {
            mycontext.companies.Update(company);
            mycontext.SaveChanges();
        }
    }
}
