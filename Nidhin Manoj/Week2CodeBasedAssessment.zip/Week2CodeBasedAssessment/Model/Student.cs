﻿namespace Week2CodeBasedAssessment.Model
{
    public class Student
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public string qualification { get; set; }
        public string skills { get; set; }
    }
}
